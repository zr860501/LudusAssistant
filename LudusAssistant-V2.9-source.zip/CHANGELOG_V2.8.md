# V2.8 changelog

- AccountSnapshotStore: persistent normalized account snapshot with provenance.
- AccountSnapshotBuilder: merges observed local resource state into the normalized snapshot.
- ShopAdvisor: missing resource values now remain unknown instead of defaulting to zero.
- HeroRepository: unverified sample heroes no longer carry fabricated S/A ratings.
- MainActivity: displays snapshot timestamp/source when available.
- Version: 2.8.0 (versionCode 25).
