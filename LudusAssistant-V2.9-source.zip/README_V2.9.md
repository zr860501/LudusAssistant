# LUDUS Assistant V2.9

## Automation/task orchestration baseline

This release adds a planning/state layer for the confirmed daily workflow. Planning is separate from execution.

### Rules
- Daily login can be scheduled automatically.
- Free rewards, event tasks, token tasks and PVP require explicit user approval before execution.
- A PVP match blocks unrelated ad-reward execution; ad work is deferred until the match ends.
- Ad cooldown is enforced from observed timestamps.
- Resource scans and shop checks can be scheduled without pretending that game controls have executed.
- A planned task is not evidence that the action succeeded; execution must later report an observed result.

### Verification
`AutomationPlannerTest` is a pure-Java regression test and can run without an Android device or network.
