# Ludus Assistant V2.2

本版本在 V2.1 基础上增加“账号感知购买建议”。

## 新增
- 官方商店公开目录增加免费商品快照：Free Emeralds、Free Gold、Clan Medals、Atlantis Tokens。
- `ShopAdvisor` 根据本机实时资源账本生成保守的购买建议。
- 纯资源（Emerald/Gold）按同质资源单位价值比较。
- 英雄、Astral Echo、符文等异质资源不强行折现，不制造虚假综合评分。
- 购买仍必须进入官方 Web Shop/Xsolla，并由用户最终确认。

## 数据来源原则
商店商品、价格、免费商品状态以官方 Web Shop 当前页面为准；公开快照可能变化，App 不把静态快照当成实时支付报价。

## 当前安全边界
本工程不实现绕过认证、伪造国家/地区价格、修改服务器数据或自动完成付费订单。
