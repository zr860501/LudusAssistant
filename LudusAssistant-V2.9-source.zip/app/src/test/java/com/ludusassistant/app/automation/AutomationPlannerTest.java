package com.ludusassistant.app.automation;

import java.util.Arrays;
import java.util.List;

public final class AutomationPlannerTest {
    public static void main(String[] args) {
        long now = 1_000_000L;
        List<AutomationTask> plan = AutomationPlanner.buildDailyPlan(false, true, true, true, true, true, true, now);
        check(plan.get(0).type == TaskType.DAILY_LOGIN, "login first");
        check(plan.size() == 7, "all seven expected");

        AutomationPlanner.approve(plan, Arrays.asList("free-reward", "event-task", "token-task", "pvp"));
        check(plan.get(1).state == TaskState.APPROVED, "free reward approved");
        check(plan.get(2).state == TaskState.APPROVED, "event approved");

        AutomationTask duringMatch = AutomationPlanner.nextRunnable(plan, now, 0, true);
        check(duringMatch != null && duringMatch.type != TaskType.AD_REWARD, "no ad during match");

        AutomationTask pvp = null;
        for (AutomationTask t : plan) if (t.type == TaskType.PVP_MATCH) pvp = t;
        check(pvp != null && pvp.state == TaskState.APPROVED, "pvp approved");
        check(AutomationPlanner.stateAfterMatch(true) == TaskState.WAITING_FOR_AD, "ad deferred after match");

        AutomationTask ad = new AutomationTask("ad", TaskType.AD_REWARD, "ad", 50, true, now, 60_000);
        ad.state = TaskState.APPROVED;
        check(!ad.eligible(now + 30_000, now, false), "ad cooldown enforced");
        check(ad.eligible(now + 60_000, now, false), "ad becomes eligible after cooldown");
        System.out.println("AutomationPlannerTest: PASS");
    }

    private static void check(boolean value, String name) {
        if (!value) throw new AssertionError(name);
    }
}
