package com.ludusassistant.app.vision;

/** OCR token with its screen position. Coordinates are pixels in the captured frame. */
public final class OcrToken {
    public final String text;
    public final float confidence;
    public final int left, top, right, bottom;
    public OcrToken(String text, float confidence, int left, int top, int right, int bottom) {
        this.text = text == null ? "" : text;
        this.confidence = confidence;
        this.left = left; this.top = top; this.right = right; this.bottom = bottom;
    }
    public int centerX() { return (left + right) / 2; }
    public int centerY() { return (top + bottom) / 2; }
}
