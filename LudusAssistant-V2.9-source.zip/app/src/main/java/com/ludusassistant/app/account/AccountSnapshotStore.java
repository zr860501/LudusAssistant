package com.ludusassistant.app.account;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Persists the latest normalized account snapshot and its provenance. */
public final class AccountSnapshotStore {
    private static final String PREF = "ludus_account_snapshot";
    private static final String KEY = "snapshot";
    private final SharedPreferences p;

    public AccountSnapshotStore(Context context) {
        p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public synchronized void save(AccountSnapshot snapshot, String source, float confidence) {
        if (snapshot == null) return;
        try {
            JSONObject o = snapshot.toJson();
            o.put("source", source == null ? "unknown" : source);
            o.put("confidence", confidence);
            p.edit().putString(KEY, o.toString()).apply();
        } catch (Exception ignored) { }
    }

    public synchronized JSONObject raw() {
        try { return new JSONObject(p.getString(KEY, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    public synchronized long observedAt() { return raw().optLong("observedAt", 0); }
    public synchronized String source() { return raw().optString("source", "unknown"); }
    public synchronized float confidence() { return (float) raw().optDouble("confidence", 0); }

    public synchronized AccountSnapshot get() {
        JSONObject o = raw();
        return new AccountSnapshot(
                o.optString("playerId", ""),
                o.optLong("observedAt", 0),
                o.optJSONObject("resources"),
                o.optJSONArray("heroes"),
                o.optJSONArray("spells"),
                o.optJSONObject("pvp"),
                o.optJSONArray("events"));
    }

    public synchronized void clear() { p.edit().remove(KEY).apply(); }
}
