package com.ludusassistant.app.vision.parser;

import com.ludusassistant.app.vision.OcrToken;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative parser for resource counters whose icons have no text label.
 * It associates numeric OCR tokens with configurable normalized screen regions.
 * No value is emitted unless the token is numeric and the region is explicitly configured.
 */
public final class SpatialResourceParser {
    public static final class Region {
        public final String resource;
        public final float left, top, right, bottom;
        public final float minConfidence;
        public Region(String resource, float left, float top, float right, float bottom, float minConfidence) {
            this.resource = resource; this.left = left; this.top = top; this.right = right; this.bottom = bottom;
            this.minConfidence = minConfidence;
        }
    }

    private static final Pattern NUMBER = Pattern.compile("^[0-9][0-9,\\s]*$");
    private final List<Region> regions;

    public SpatialResourceParser(List<Region> regions) { this.regions = regions; }

    public Map<String, Long> parse(List<OcrToken> tokens, int width, int height) {
        Map<String, Long> out = new LinkedHashMap<>();
        if (tokens == null || width <= 0 || height <= 0) return out;
        for (Region region : regions) {
            OcrToken best = null;
            for (OcrToken token : tokens) {
                if (token == null || token.confidence < region.minConfidence || !NUMBER.matcher(token.text.trim()).matches()) continue;
                float x = token.centerX() / (float) width;
                float y = token.centerY() / (float) height;
                if (x >= region.left && x <= region.right && y >= region.top && y <= region.bottom) {
                    if (best == null || token.confidence > best.confidence) best = token;
                }
            }
            if (best != null) {
                String digits = best.text.replace(",", "").replace(" ", "");
                try { out.put(region.resource, Long.parseLong(digits)); } catch (NumberFormatException ignored) { }
            }
        }
        return out;
    }
}
