package com.ludusassistant.app.vision.model;

import java.util.Collections;
import java.util.Map;

public final class ScreenObservation {
    public final long timestamp;
    public final GamePage page;
    public final Map<String, String> text;
    public final float confidence;

    public ScreenObservation(long timestamp, GamePage page, Map<String, String> text, float confidence) {
        this.timestamp = timestamp;
        this.page = page;
        this.text = text == null ? Collections.emptyMap() : Collections.unmodifiableMap(text);
        this.confidence = confidence;
    }
}
