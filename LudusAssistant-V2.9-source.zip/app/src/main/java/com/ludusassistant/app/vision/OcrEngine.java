package com.ludusassistant.app.vision;

import android.graphics.Bitmap;
import android.media.Image;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * On-device OCR. Bundled models keep the recognition path usable offline after installation.
 * A single in-flight task is allowed; new frames are dropped while OCR is busy.
 */
public final class OcrEngine implements AutoCloseable {
    public static final class Result {
        public final String text;
        public final float confidence;
        public final int width;
        public final int height;
        public final List<OcrToken> tokens;
        Result(String text, float confidence, int width, int height, List<OcrToken> tokens) {
            this.text = text == null ? "" : text;
            this.confidence = confidence;
            this.width = width;
            this.height = height;
            this.tokens = tokens == null ? java.util.Collections.emptyList() : java.util.Collections.unmodifiableList(tokens);
        }
    }

    private final TextRecognizer latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private final TextRecognizer chinese = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
    private final AtomicBoolean busy = new AtomicBoolean(false);

    /** Returns false when an OCR task is already running. */
    public boolean submit(Image image, BiConsumer<Result, Exception> callback) {
        if (image == null || !busy.compareAndSet(false, true)) return false;
        final Bitmap bitmap;
        try {
            bitmap = toBitmap(image);
        } catch (Exception e) {
            busy.set(false);
            if (callback != null) callback.accept(null, e);
            return false;
        }
        InputImage input = InputImage.fromBitmap(bitmap, 0);
        latin.process(input)
                .addOnSuccessListener(result -> {
                    if (containsCjk(result.getText())) {
                        chinese.process(input)
                                .addOnSuccessListener(ch -> finish(bitmap, ch, callback))
                                .addOnFailureListener(e -> finish(bitmap, result, callback))
                                .addOnCompleteListener(t -> busy.set(false));
                    } else {
                        finish(bitmap, result, callback);
                        busy.set(false);
                    }
                })
                .addOnFailureListener(e -> {
                    finish(bitmap, null, callback, e);
                    busy.set(false);
                });
        return true;
    }

    private void finish(Bitmap bitmap, Text result, BiConsumer<Result, Exception> callback) {
        finish(bitmap, result, callback, null);
    }

    private void finish(Bitmap bitmap, Text result, BiConsumer<Result, Exception> callback, Exception error) {
        try {
            if (callback == null) return;
            if (error != null || result == null) {
                callback.accept(null, error == null ? new IllegalStateException("OCR returned no result") : error);
                return;
            }
            float confidence = averageConfidence(result);
            callback.accept(new Result(result.getText(), confidence, bitmap.getWidth(), bitmap.getHeight(), extractTokens(result)), null);
        } finally {
            bitmap.recycle();
        }
    }


    private static List<OcrToken> extractTokens(Text result) {
        List<OcrToken> tokens = new ArrayList<>();
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element el : line.getElements()) {
                    android.graphics.Rect r = el.getBoundingBox();
                    if (r == null) continue;
                    Float c = el.getConfidence();
                    tokens.add(new OcrToken(el.getText(), c == null ? 0.5f : c, r.left, r.top, r.right, r.bottom));
                }
            }
        }
        return tokens;
    }

    private static float averageConfidence(Text result) {
        float sum = 0f; int count = 0;
        for (Text.TextBlock block : result.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element el : line.getElements()) {
                    Float c = el.getConfidence();
                    if (c != null && c >= 0f) { sum += c; count++; }
                }
            }
        }
        return count == 0 ? 0.5f : sum / count;
    }

    private static boolean containsCjk(String s) {
        if (s == null) return false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= 0x3400 && c <= 0x9FFF) || (c >= 0xF900 && c <= 0xFAFF)) return true;
        }
        return false;
    }

    private static Bitmap toBitmap(Image image) {
        if (image.getFormat() != android.graphics.ImageFormat.RGBA_8888 && image.getPlanes().length == 0) {
            throw new IllegalArgumentException("Unsupported capture image format: " + image.getFormat());
        }
        Image.Plane plane = image.getPlanes()[0];
        ByteBuffer buffer = plane.getBuffer();
        int width = image.getWidth(), height = image.getHeight();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * width;
        Bitmap padded = Bitmap.createBitmap(width + Math.max(0, rowPadding / Math.max(1, pixelStride)), height, Bitmap.Config.ARGB_8888);
        buffer.rewind();
        padded.copyPixelsFromBuffer(buffer);
        if (padded.getWidth() == width) return padded;
        Bitmap cropped = Bitmap.createBitmap(padded, 0, 0, width, height);
        padded.recycle();
        return cropped;
    }

    @Override public void close() {
        latin.close();
        chinese.close();
    }
}
