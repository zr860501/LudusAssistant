package com.ludusassistant.app.automation;

/** A planned action. Planning never implies permission to execute it. */
public final class AutomationTask {
    public final String id;
    public final TaskType type;
    public final String title;
    public final int priority;
    public final boolean requiresApproval;
    public final long earliestAt;
    public final long adCooldownMs;
    public TaskState state;

    public AutomationTask(String id, TaskType type, String title, int priority,
                          boolean requiresApproval, long earliestAt, long adCooldownMs) {
        this.id = id == null ? "" : id;
        this.type = type;
        this.title = title == null ? "" : title;
        this.priority = priority;
        this.requiresApproval = requiresApproval;
        this.earliestAt = earliestAt;
        this.adCooldownMs = Math.max(0, adCooldownMs);
        this.state = TaskState.AVAILABLE;
    }

    public boolean eligible(long now, long lastAdAt, boolean inMatch) {
        if (state != TaskState.AVAILABLE && state != TaskState.APPROVED) return false;
        if (now < earliestAt) return false;
        if (type == TaskType.AD_REWARD && lastAdAt > 0 && now - lastAdAt < adCooldownMs) return false;
        if (inMatch && type != TaskType.PVP_MATCH) return false;
        return true;
    }
}
