package com.ludusassistant.app.sync;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;

public final class NetworkState {
    private NetworkState(){}
    public static boolean connected(Context c){
        ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm==null) return false;
        Network n=cm.getActiveNetwork();
        return n!=null && cm.getNetworkCapabilities(n)!=null;
    }
}
