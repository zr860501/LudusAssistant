package com.ludusassistant.app.vision;

import com.ludusassistant.app.vision.model.GamePage;
import com.ludusassistant.app.vision.model.ScreenObservation;
import com.ludusassistant.app.vision.parser.ResourceTextParser;
import com.ludusassistant.app.vision.parser.ScreenTextParser;
import com.ludusassistant.app.vision.parser.ExpandedResourcePanelParser;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;

/** Converts an OCR result into a conservative, auditable observation. */
public final class ObservationPipeline {
    private final SpatialResourceParser spatial = new SpatialResourceParser(ResourceRegionProfiles.ludusTopBarV1());
    private final ExpandedResourcePanelParser expandedPanel = new ExpandedResourcePanelParser();

    public ScreenObservation process(String ocrText, float confidence) {
        GamePage page = ScreenTextParser.classify(ocrText);
        Map<String, String> fields = new LinkedHashMap<>();
        for (Map.Entry<String, Long> e : ResourceTextParser.parse(ocrText).entrySet()) {
            fields.put(e.getKey(), String.valueOf(e.getValue()));
        }
        return new ScreenObservation(System.currentTimeMillis(), page, fields, confidence);
    }

    /** Adds icon-only resource counters after OCR positions are available. */
    public ScreenObservation process(OcrEngine.Result result) {
        if (result == null) return process("", 0f);
        ScreenObservation base = process(result.text, result.confidence);
        Map<String, String> fields = new LinkedHashMap<>(base.text);
        for (Map.Entry<String, Long> e : expandedPanel.parse(result.tokens).entrySet()) {
            fields.put(e.getKey(), String.valueOf(e.getValue()));
        }
        for (Map.Entry<String, Long> e : spatial.parse(result.tokens, result.width, result.height).entrySet()) {
            fields.putIfAbsent(e.getKey(), String.valueOf(e.getValue()));
        }
        return new ScreenObservation(base.timestamp, base.page, fields, base.confidence);
    }
}
