package com.ludusassistant.app.account;

import android.content.Context;
import android.content.SharedPreferences;

public final class PlayerIdStore {
    private static final String PREF = "ludus_account";
    private static final String KEY_PLAYER_ID = "player_id";
    private final SharedPreferences prefs;

    public PlayerIdStore(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public String get() { return prefs.getString(KEY_PLAYER_ID, ""); }

    public void set(String value) {
        prefs.edit().putString(KEY_PLAYER_ID, value == null ? "" : value.trim()).apply();
    }

    public static boolean isValid(String id) {
        return id != null && id.trim().matches("[0-9A-Za-z_-]{4,32}");
    }
}
