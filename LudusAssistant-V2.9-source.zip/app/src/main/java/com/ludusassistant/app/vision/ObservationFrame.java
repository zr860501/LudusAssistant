package com.ludusassistant.app.vision;

/** Immutable description of a captured game frame supplied by a future MediaProjection/OCR adapter. */
public final class ObservationFrame {
    public final long timestamp;
    public final int width;
    public final int height;
    public ObservationFrame(long timestamp,int width,int height){this.timestamp=timestamp;this.width=width;this.height=height;}
}
