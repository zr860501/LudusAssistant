package com.ludusassistant.app.vision.model;

public enum GamePage {
    UNKNOWN, HOME, PVP, BATTLE, REWARD, CHEST, EVENTS, HEROES, SPELLS, SHOP, CLAN, PROFILE,
    ADVERTISEMENT, EXTERNAL_APP_INSTALL
}
