package com.ludusassistant.app.shop;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Current public catalog snapshot. Prices are USD values published by the official shop crawl.
 * This is a cache, not a payment API. Refresh it when the official shop changes.
 */
public final class ShopCatalog {
    private ShopCatalog() {}

    public static List<ShopItem> currentPublicSnapshot() {
        List<ShopItem> x = new ArrayList<>();
        x.add(new ShopItem("Free emeralds", "Free", 0, 0, 100, 0, 0, false, "free-emeralds"));
        x.add(new ShopItem("Free Gold", "Free", 0, 0, 0, 500, 0, false, "free-gold"));
        x.add(new ShopItem("Clan Medals", "Free", 0, 0, 0, 0, 0, false, "clan-medals"));
        x.add(new ShopItem("Atlantis Tokens", "Free", 0, 0, 0, 0, 0, false, "atlantis-tokens"));
        x.add(new ShopItem("Small pile of emeralds", "Emeralds", 5.40, 5.99, 650, 0, 5, true, ""));
        x.add(new ShopItem("Pouch of emeralds", "Emeralds", 10.80, 11.99, 1500, 0, 10, true, ""));
        x.add(new ShopItem("Sack of emeralds", "Emeralds", 21.60, 23.99, 3200, 0, 20, true, ""));
        x.add(new ShopItem("Chest of emeralds", "Emeralds", 54.00, 59.99, 8300, 0, 50, true, ""));
        x.add(new ShopItem("Pot of emeralds", "Emeralds", 108.00, 119.99, 17500, 0, 99, true, ""));
        x.add(new ShopItem("Small pile of gold", "Gold", 2.88, 3.20, 0, 5000, 3, false, ""));
        x.add(new ShopItem("Piggy bank of gold", "Gold", 10.71, 11.89, 0, 25000, 10, false, ""));
        x.add(new ShopItem("Carpetbag of gold", "Gold", 20.07, 22.30, 0, 60000, 19, false, ""));
        x.add(new ShopItem("Goblet of gold", "Gold", 38.70, 42.99, 0, 140000, 36, false, ""));
        x.add(new ShopItem("Strongbox of gold", "Gold", 73.40, 81.55, 0, 350000, 68, false, ""));
        x.add(new ShopItem("Small welcome bundle", "Special offers", 5.40, 5.99, 300, 15000, 5, false, ""));
        x.add(new ShopItem("Medium welcome bundle", "Special offers", 54.00, 59.99, 3000, 150000, 50, false, ""));
        x.add(new ShopItem("Big welcome bundle", "Special offers", 108.00, 119.99, 6000, 300000, 99, false, ""));
        x.add(new ShopItem("Uruk Bundle", "Special offers", 54.00, 59.99, 2000, 100000, 50, false, ""));
        return Collections.unmodifiableList(x);
    }

    public static ShopItem bestForEmeralds() {
        return currentPublicSnapshot().stream()
                .filter(i -> i.emeralds > 0)
                .max(Comparator.comparingDouble(ShopItem::emeraldsPerUsd))
                .orElse(null);
    }

    public static ShopItem bestForGold() {
        return currentPublicSnapshot().stream()
                .filter(i -> i.gold > 0)
                .max(Comparator.comparingDouble(ShopItem::goldPerUsd))
                .orElse(null);
    }

    public static ShopItem bestForStorePoints() {
        return currentPublicSnapshot().stream()
                .filter(i -> i.storePoints > 0)
                .max(Comparator.comparingDouble(ShopItem::pointsPerUsd))
                .orElse(null);
    }
}
