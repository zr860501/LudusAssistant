package com.ludusassistant.app.automation;

public enum TaskType {
    DAILY_LOGIN,
    FREE_REWARD,
    AD_REWARD,
    TOKEN_TASK,
    PVP_MATCH,
    EVENT_TASK,
    RESOURCE_SCAN,
    SHOP_CHECK
}
