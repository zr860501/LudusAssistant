package com.ludusassistant.app.hero;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** Version-aware hero knowledge base. Unknown classifications stay explicitly unverified. */
public final class HeroRepository {
    private final List<Hero> heroes = new ArrayList<>();
    public HeroRepository(Context context){ seed(); }
    private void seed(){
        heroes.clear();
        add("storm","Storm","待验证","待验证","待验证","DPS/近战","Storm Sigil、穿透攻击、近战伤害反射","高生命值前排型输出；优先保证存活，再利用技能持续压制。","1.36.x");
        add("princess","Princess","待验证","待验证","待验证","坦克/控制","范围伤害、眩晕、复活机制","前排承伤并制造控制窗口；适合需要稳定前排的阵容。","1.36.x");
        add("mako","Mako","待验证","待验证","待验证","输出/位移","鱼叉位移敌方后排输出","利用站位与拉取目标破坏敌方核心输出位置。","1.36.x");
        add("muerta","Muerta","待验证","待验证","待验证","召唤","召唤Crypt并持续召唤Skeleton","保护召唤核心，搭配额外前排；适合持续作战。","1.36.x");
        add("gunbot","Gunbot","待验证","待验证","待验证","远程DPS","直线激光攻击","利用安全距离持续输出；前排保护优先。","1.36.x");
        add("gingerbread_man","Gingerbread Man","待验证","待验证","待验证","近战/控制","锥形范围伤害与眩晕","需要前排保护，利用范围控制制造输出窗口。","1.36.x");
        add("chainsaw","Chainsaw","待验证","待验证","待验证","待验证","待补充","新版本英雄；等待游戏内观测与版本资料验证。","1.36.x");
    }
    private void add(String... x){heroes.add(new Hero(x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[8]));}
    public List<Hero> list(){ return Collections.unmodifiableList(heroes); }
    public JSONArray all(){return filter(null,null,null);}
    public JSONArray filter(String race,String faction,String rarity){
        JSONArray a=new JSONArray();
        for(Hero h:heroes){
            if(race!=null&&!race.isEmpty()&&!race.equals(h.race)) continue;
            if(faction!=null&&!faction.isEmpty()&&!faction.equals(h.faction)) continue;
            if(rarity!=null&&!rarity.isEmpty()&&!rarity.equals(h.rarity)) continue;
            try{a.put(toJson(h));}catch(Exception ignored){}
        }
        return a;
    }
    private JSONObject toJson(Hero h)throws Exception{return new JSONObject().put("id",h.id).put("name",h.name).put("race",h.race).put("faction",h.faction).put("rarity",h.rarity).put("role",h.role).put("ability",h.ability).put("gameplay",h.gameplay).put("version",h.version);}
    public String grouped(){
        Map<String,List<Hero>> m=new LinkedHashMap<>();
        for(Hero h:heroes)m.computeIfAbsent(h.faction,k->new ArrayList<>()).add(h);
        StringBuilder s=new StringBuilder();
        for(Map.Entry<String,List<Hero>> e:m.entrySet()){
            s.append("【阵营：").append(e.getKey()).append("】\n");
            for(Hero h:e.getValue())s.append("• ").append(h.name).append(" · ").append(h.rarity).append(" · ").append(h.role).append("\n");
        }
        return s.toString();
    }
    public String detail(String id){
        for(Hero h:heroes) if(h.id.equals(id)) return "【"+h.name+"】\n种族："+h.race+"\n阵营："+h.faction+"\n稀有度："+h.rarity+"\n定位："+h.role+"\n技能："+h.ability+"\n玩法："+h.gameplay+"\n适用版本："+h.version;
        return "未找到英雄";
    }
}
