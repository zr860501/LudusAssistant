package com.ludusassistant.app.data;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class RefreshScheduler {
    public static void schedule(Context c){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c,RefreshReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(c,2201,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        long t=System.currentTimeMillis()+60L*60L*1000L;
        if(am!=null) am.setInexactRepeating(AlarmManager.RTC_WAKEUP,t,60L*60L*1000L,pi);
    }
}
