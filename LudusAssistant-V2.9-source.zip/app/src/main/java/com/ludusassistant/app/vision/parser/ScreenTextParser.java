package com.ludusassistant.app.vision.parser;

import com.ludusassistant.app.vision.model.GamePage;
import java.util.Locale;

/** Conservative parser for English and Simplified Chinese game/ad screens. */
public final class ScreenTextParser {
    private ScreenTextParser() {}

    public static GamePage classify(String raw) {
        if (raw == null || raw.trim().isEmpty()) return GamePage.UNKNOWN;
        String s = raw.toLowerCase(Locale.ROOT);

        // The supplied Mate 60 Pro recording shows an external ad and then an app-install card.
        if (containsAny(s, "play now", "立即游戏", "广告", "ad", "sponsored")) return GamePage.ADVERTISEMENT;
        if (containsAny(s, "安装", "install", "clash of clans", "google play")) return GamePage.EXTERNAL_APP_INSTALL;

        if (containsAny(s, "battle", "vs", "arena", "对战", "战斗")) return GamePage.BATTLE;
        if (containsAny(s, "events", "event", "tournament", "活动", "锦标赛")) return GamePage.EVENTS;
        if (containsAny(s, "chest", "reward", "rewards", "宝箱", "奖励", "宝库")) return GamePage.REWARD;
        if (containsAny(s, "heroes", "hero", "英雄", "卡牌")) return GamePage.HEROES;
        if (containsAny(s, "spells", "spell", "法术")) return GamePage.SPELLS;
        if (containsAny(s, "clan", "wars", "联盟", "部落", "公会")) return GamePage.CLAN;
        if (containsAny(s, "shop", "store", "商店", "商城")) return GamePage.SHOP;
        if (containsAny(s, "pvp", "duel", "竞技场", "决斗")) return GamePage.PVP;
        if (containsAny(s, "设置", "settings")) return GamePage.PROFILE;
        return GamePage.HOME;
    }

    private static boolean containsAny(String value, String... terms) {
        for (String term : terms) if (value.contains(term)) return true;
        return false;
    }
}
