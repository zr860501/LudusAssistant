package com.ludusassistant.app.shop;

/** A quote copied from the official checkout page for a specific currency/payment method. */
public final class CurrencyQuote {
    public final String currency;
    public final double amount;
    public final double cnyTotal;
    public final String paymentMethod;

    public CurrencyQuote(String currency, double amount, double cnyTotal, String paymentMethod) {
        this.currency = currency;
        this.amount = amount;
        this.cnyTotal = cnyTotal;
        this.paymentMethod = paymentMethod == null ? "" : paymentMethod;
    }
}
