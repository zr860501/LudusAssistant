package com.ludusassistant.app.hero;

import java.util.*;

/** Conservative hero-development advisor. It only scores fields that are explicitly verified. */
public final class HeroAdvisor {
    private HeroAdvisor() {}

    public static List<Recommendation> recommend(List<Hero> heroes, String targetRole, Set<String> ownedIds) {
        List<Recommendation> out = new ArrayList<>();
        if (heroes == null) return out;
        for (Hero h : heroes) {
            int score = 0;
            List<String> reasons = new ArrayList<>();
            if (ownedIds != null && !ownedIds.contains(h.id)) {
                reasons.add("当前未确认已拥有");
                score -= 100;
            }
            if (h.rarity != null) {
                if ("S+".equals(h.rarity)) { score += 30; reasons.add("资料库标记为 S+"); }
                else if ("S".equals(h.rarity)) { score += 20; reasons.add("资料库标记为 S"); }
                else if ("A".equals(h.rarity)) { score += 10; }
            }
            if (targetRole != null && !targetRole.isEmpty() && h.role != null && h.role.contains(targetRole)) {
                score += 25; reasons.add("符合当前定位目标：" + targetRole);
            }
            if ("待验证".equals(h.race)) reasons.add("种族：待验证");
            if ("待验证".equals(h.faction)) reasons.add("阵营：待验证");
            if ("待验证".equals(h.rarity)) reasons.add("强度评级：待验证");
            if (reasons.isEmpty()) reasons.add("暂无足够已验证字段");
            out.add(new Recommendation(h, score, reasons));
        }
        Collections.sort(out, new Comparator<Recommendation>() {
            @Override public int compare(Recommendation a, Recommendation b) { return Integer.compare(b.score, a.score); }
        });
        return out;
    }

    public static String summary(List<Hero> heroes, String targetRole, Set<String> ownedIds, int limit) {
        List<Recommendation> rs = recommend(heroes, targetRole, ownedIds);
        StringBuilder b = new StringBuilder();
        b.append("英雄培养建议");
        if (targetRole != null && !targetRole.isEmpty()) b.append(" · 目标定位：").append(targetRole);
        b.append("\n");
        int n = Math.min(Math.max(limit, 0), rs.size());
        for (int i = 0; i < n; i++) {
            Recommendation r = rs.get(i);
            b.append(i + 1).append(". ").append(r.hero.name)
                    .append(" · ").append(r.hero.rarity)
                    .append(" · ").append(r.hero.role)
                    .append(" · 分数 ").append(r.score).append("\n");
            b.append("   ").append(join(r.reasons)).append("\n");
        }
        b.append("\n原则：种族、阵营或强度没有可靠资料时保持‘待验证’，不会用推测替换真实数据。");
        return b.toString();
    }

    private static String join(List<String> xs) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < xs.size(); i++) { if (i > 0) b.append("；"); b.append(xs.get(i)); }
        return b.toString();
    }

    public static final class Recommendation {
        public final Hero hero;
        public final int score;
        public final List<String> reasons;
        public Recommendation(Hero hero, int score, List<String> reasons) {
            this.hero = hero; this.score = score; this.reasons = Collections.unmodifiableList(new ArrayList<>(reasons));
        }
    }
}
