package com.ludusassistant.app.shop;

/** Immutable snapshot of an item visible in the official LUDUS Web Shop. */
public final class ShopItem {
    public final String name;
    public final String category;
    public final double priceUsd;
    public final double originalUsd;
    public final long emeralds;
    public final long gold;
    public final long storePoints;
    public final boolean firstPurchase;
    public final String sku;

    public ShopItem(String name, String category, double priceUsd, double originalUsd,
                    long emeralds, long gold, long storePoints,
                    boolean firstPurchase, String sku) {
        this.name = name;
        this.category = category;
        this.priceUsd = priceUsd;
        this.originalUsd = originalUsd;
        this.emeralds = emeralds;
        this.gold = gold;
        this.storePoints = storePoints;
        this.firstPurchase = firstPurchase;
        this.sku = sku;
    }

    public double discountPercent() {
        if (originalUsd <= 0 || originalUsd <= priceUsd) return 0.0;
        return (1.0 - priceUsd / originalUsd) * 100.0;
    }

    public double emeraldsPerUsd() {
        return priceUsd <= 0 ? 0 : emeralds / priceUsd;
    }

    public double goldPerUsd() {
        return priceUsd <= 0 ? 0 : gold / priceUsd;
    }

    public double pointsPerUsd() {
        return priceUsd <= 0 ? 0 : storePoints / priceUsd;
    }
}
