package com.ludusassistant.app.data;

import com.ludusassistant.app.account.AccountSnapshot;
import com.ludusassistant.app.account.AccountSnapshotStore;
import org.json.JSONArray;
import org.json.JSONObject;

/** Builds a normalized account snapshot from independently observed fields. */
public final class AccountSnapshotBuilder {
    private AccountSnapshotBuilder() {}

    public static AccountSnapshot fromObserved(String playerId, AppStore store, AccountSnapshot previous) {
        JSONObject resources = store == null ? new JSONObject() : store.resources();
        JSONArray heroes = previous == null ? new JSONArray() : previous.heroes;
        JSONArray spells = previous == null ? new JSONArray() : previous.spells;
        JSONObject pvp = previous == null ? new JSONObject() : previous.pvp;
        JSONArray events = previous == null ? new JSONArray() : previous.events;
        return new AccountSnapshot(playerId, System.currentTimeMillis(), resources, heroes, spells, pvp, events);
    }
}
