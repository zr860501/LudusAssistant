package com.ludusassistant.app.automation;

public enum TaskState {
    AVAILABLE,
    APPROVED,
    RUNNING,
    WAITING_FOR_MATCH,
    WAITING_FOR_AD,
    CLAIMED,
    SKIPPED,
    BLOCKED,
    FAILED
}
