package com.ludusassistant.app.vision.parser;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extracts only explicitly labelled resource values from OCR text. */
public final class ResourceTextParser {
    private static final Pattern LABEL = Pattern.compile(
            "(?i)(diamonds?|emeralds?|gold|tokens?|coins?|钻石|祖母绿|金币|代币|奖杯)\\s*[:：]?\\s*([0-9][0-9,\\s]*)");
    private ResourceTextParser() {}

    public static Map<String, Long> parse(String text) {
        Map<String, Long> result = new LinkedHashMap<>();
        if (text == null) return result;
        Matcher m = LABEL.matcher(text);
        while (m.find()) {
            String key = normalize(m.group(1));
            String digits = m.group(2).replace(",", "").replace(" ", "");
            try { result.put(key, Long.parseLong(digits)); } catch (NumberFormatException ignored) { }
        }
        return result;
    }

    private static String normalize(String s) {
        String v = s.toLowerCase();
        if (v.startsWith("diamond") || s.contains("钻石")) return "diamonds";
        if (v.startsWith("emerald") || s.contains("祖母绿")) return "emeralds";
        if (v.startsWith("token") || s.contains("代币")) return "tokens";
        if (s.contains("奖杯")) return "trophies";
        return v.startsWith("coin") || s.contains("金币") ? "gold" : "gold";
    }
}
