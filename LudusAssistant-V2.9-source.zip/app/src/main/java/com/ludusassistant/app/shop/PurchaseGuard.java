package com.ludusassistant.app.shop;

/** Prevents the assistant from placing a paid order without an explicit user confirmation. */
public final class PurchaseGuard {
    private boolean confirmed;

    public void requireExplicitConfirmation() { confirmed = false; }
    public void confirm() { confirmed = true; }
    public boolean canProceedToOfficialCheckout() { return confirmed; }
}
