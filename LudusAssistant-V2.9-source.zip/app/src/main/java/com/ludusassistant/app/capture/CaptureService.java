package com.ludusassistant.app.capture;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import com.ludusassistant.app.data.AppStore;
import com.ludusassistant.app.vision.OcrEngine;
import com.ludusassistant.app.vision.ObservationPipeline;
import com.ludusassistant.app.vision.model.ScreenObservation;

public final class CaptureService extends Service {
    public static final String ACTION_START = "com.ludusassistant.app.capture.START";
    public static final String ACTION_STOP = "com.ludusassistant.app.capture.STOP";
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_DATA = "projection_data";
    private static final String CHANNEL = "capture";
    private static final int NOTIFICATION_ID = 4107;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private long lastFrameNs;
    private int frameCount;
    private OcrEngine ocr;
    private final ObservationPipeline pipeline = new ObservationPipeline();
    private AppStore store;

    @Override public void onCreate() { super.onCreate(); createChannel(); store = new AppStore(this); ocr = new OcrEngine(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_STOP.equals(intent.getAction())) {
            stopCapture(); stopSelf(); return START_NOT_STICKY;
        }
        if (ACTION_START.equals(intent.getAction())) {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
            Intent data = Build.VERSION.SDK_INT >= 33
                    ? intent.getParcelableExtra(EXTRA_DATA, Intent.class)
                    : (Intent) intent.getParcelableExtra(EXTRA_DATA);
            startForegroundNow();
            if (data != null && resultCode != 0) startCapture(resultCode, data);
        }
        return START_NOT_STICKY;
    }

    private void startCapture(int resultCode, Intent data) {
        stopCapture();
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(resultCode, data);
        if (projection == null) return;
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopCapture(); stopSelf(); }
        }, null);

        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        int density = dm.densityDpi;
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        imageReader.setOnImageAvailableListener(reader -> {
            Image image = null;
            try {
                image = reader.acquireLatestImage();
                if (image == null) return;
                long now = System.nanoTime();
                if (now - lastFrameNs < 250_000_000L) return;
                lastFrameNs = now;
                frameCount++;
                SharedPreferences p = getSharedPreferences("ludus_capture", MODE_PRIVATE);
                p.edit().putLong("last_frame_ms", System.currentTimeMillis())
                        .putInt("width", image.getWidth())
                        .putInt("height", image.getHeight())
                        .putInt("frames", frameCount)
                        .apply();
                // Copy/submit before closing the Image. OCR owns the copied Bitmap, not the Image.
                if (ocr != null) {
                    ocr.submit(image, (result, error) -> {
                        if (result == null) {
                            p.edit().putString("last_ocr_error", error == null ? "unknown" : error.getClass().getSimpleName())
                                    .apply();
                            return;
                        }
                        ScreenObservation obs = pipeline.process(result);
                        SharedPreferences.Editor e = p.edit()
                                .putLong("last_observation_ms", obs.timestamp)
                                .putString("last_page", obs.page.name())
                                .putFloat("last_ocr_confidence", obs.confidence)
                                .putString("last_ocr_text", result.text.length() > 2000 ? result.text.substring(0, 2000) : result.text);
                        e.apply();
                        for (java.util.Map.Entry<String, String> field : obs.text.entrySet()) {
                            try {
                                long value = Long.parseLong(field.getValue());
                                long old = store.resources().optLong(field.getKey(), Long.MIN_VALUE);
                                if (old == Long.MIN_VALUE || old != value) {
                                    store.observe(field.getKey(), value, result.tokens.isEmpty() ? "ocr" : "ocr+spatial");
                                }
                            } catch (NumberFormatException ignored) { }
                        }
                    });
                }
            } finally { if (image != null) image.close(); }
        }, null);
        virtualDisplay = projection.createVirtualDisplay(
                "LudusAssistantCapture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, null);
    }

    private void startForegroundNow() {
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("LUDUS Assistant")
                .setContentText("正在进行屏幕观测（仅记录/分析，不自动操作游戏）")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else startForeground(NOTIFICATION_ID, n);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "屏幕观测", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void stopCapture() {
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (imageReader != null) { imageReader.close(); imageReader = null; }
        MediaProjection p = projection;
        projection = null;
        if (p != null) p.stop();
    }

    @Override public void onDestroy() { stopCapture(); if (ocr != null) { ocr.close(); ocr = null; } super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
