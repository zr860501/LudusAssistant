package com.ludusassistant.app.data;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Versioned, hourly-refreshed local guide cache. Network ingestion is intentionally separated. */
public final class GuideRepository {
    private final SharedPreferences p;
    private static final long HOUR=60L*60L*1000L;
    public GuideRepository(Context c){p=c.getSharedPreferences("ludus_guides",Context.MODE_PRIVATE);}
    public boolean due(){return System.currentTimeMillis()-lastUpdated()>=HOUR;}
    public long lastUpdated(){return p.getLong("updated",0);}
    public String version(){return p.getString("version","unknown");}
    public JSONArray current(){try{return new JSONArray(p.getString("items",defaultGuides().toString()));}catch(Exception e){return defaultGuides();}}
    public synchronized void replace(JSONArray items,String gameVersion){p.edit().putString("items",items.toString()).putString("version",gameVersion==null?"unknown":gameVersion).putLong("updated",System.currentTimeMillis()).apply();}
    private JSONArray defaultGuides(){
        JSONArray a=new JSONArray();
        try{
            a.put(new JSONObject().put("title","碎岩术：开局策略（待版本数据验证）").put("priority","待验证").put("confidence","low"));
            a.put(new JSONObject().put("title","PVP：记录对手法术并比较后续回合选择").put("priority","高").put("confidence","medium"));
            a.put(new JSONObject().put("title","活动：按单位时间奖励效率排序").put("priority","高").put("confidence","medium"));
        }catch(Exception ignored){}
        return a;
    }
}
