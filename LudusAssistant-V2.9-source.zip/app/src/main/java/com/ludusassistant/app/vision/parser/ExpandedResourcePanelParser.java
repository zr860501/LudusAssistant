package com.ludusassistant.app.vision.parser;

import com.ludusassistant.app.vision.OcrToken;
import com.ludusassistant.app.vision.resource.LudusResourceCatalog;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Parses the expanded LUDUS resource panel from OCR tokens.
 * A value is accepted only when a recognized resource label and a nearby numeric token
 * form a plausible pair. This avoids confusing unrelated numbers elsewhere on screen.
 */
public final class ExpandedResourcePanelParser {
    private static final Pattern NUMBER = Pattern.compile("^[0-9][0-9,\\s]*$");
    private static final int MAX_VERTICAL_GAP = 90;
    private static final int MAX_HORIZONTAL_GAP = 260;

    public Map<String, Long> parse(List<OcrToken> tokens) {
        Map<String, Long> out = new LinkedHashMap<>();
        if (tokens == null) return out;
        for (OcrToken labelToken : tokens) {
            String key = keyFor(labelToken == null ? null : labelToken.text);
            if (key == null || labelToken.confidence < 0.55f) continue;
            OcrToken best = null;
            int bestDistance = Integer.MAX_VALUE;
            for (OcrToken numberToken : tokens) {
                if (!isNumber(numberToken) || numberToken.confidence < 0.55f) continue;
                int dx = Math.abs(numberToken.centerX() - labelToken.centerX());
                int dy = numberToken.centerY() - labelToken.centerY();
                if (dy < -10 || dy > MAX_VERTICAL_GAP || dx > MAX_HORIZONTAL_GAP) continue;
                int distance = dx + dy;
                if (distance < bestDistance) { best = numberToken; bestDistance = distance; }
            }
            if (best != null) {
                Long value = parseNumber(best.text);
                if (value != null) out.put(key, value);
            }
        }
        return out;
    }

    private static String keyFor(String raw) {
        if (raw == null) return null;
        String normalized = raw.trim().replace("：", ":").replace(":", "").toLowerCase(Locale.ROOT);
        String exact = LudusResourceCatalog.keyForLabel(normalized);
        if (exact != null) return exact;
        for (LudusResourceCatalog.Definition d : LudusResourceCatalog.definitions()) {
            for (String label : d.labels) {
                if (normalized.contains(label.toLowerCase(Locale.ROOT))) return d.key;
            }
        }
        return null;
    }

    private static boolean isNumber(OcrToken token) {
        return token != null && token.text != null && NUMBER.matcher(token.text.trim()).matches();
    }

    private static Long parseNumber(String text) {
        try { return Long.parseLong(text.replace(",", "").replace(" ", "")); }
        catch (NumberFormatException e) { return null; }
    }
}
