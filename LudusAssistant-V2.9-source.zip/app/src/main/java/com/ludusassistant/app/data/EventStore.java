package com.ludusassistant.app.data;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Local event/calendar store. Remote ingestion is deliberately separate. */
public final class EventStore {
    private final SharedPreferences p;
    private static final String KEY = "events";
    public EventStore(Context c){ p=c.getSharedPreferences("ludus_events",Context.MODE_PRIVATE); }
    public synchronized JSONArray all(){ try{return new JSONArray(p.getString(KEY,"[]"));}catch(Exception e){return new JSONArray();} }
    public synchronized void upsert(JSONObject event){
        JSONArray a=all(); String id=event.optString("id",""); boolean found=false;
        for(int i=0;i<a.length();i++){
            JSONObject old=a.optJSONObject(i);
            if(old!=null && id.equals(old.optString("id"))){ a.put(i,event); found=true; break; }
        }
        if(!found) a.put(event);
        p.edit().putString(KEY,a.toString()).apply();
    }
    public synchronized void clear(){p.edit().remove(KEY).apply();}
}
