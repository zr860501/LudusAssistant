package com.ludusassistant.app.shop;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Compares currencies only from quotes actually visible at checkout.
 * It never invents an exchange rate or recommends falsifying the purchase country.
 */
public final class CurrencyComparator {
    private CurrencyComparator() {}

    public static List<CurrencyQuote> rankByCnyCost(List<CurrencyQuote> quotes) {
        List<CurrencyQuote> copy = new ArrayList<>(quotes == null ? new ArrayList<CurrencyQuote>() : quotes);
        copy.sort(Comparator.comparingDouble(q -> q.cnyTotal));
        return copy;
    }

    public static String explain(List<CurrencyQuote> quotes) {
        if (quotes == null || quotes.isEmpty()) {
            return "尚未取得官方结算页的实际币种报价。请在官方支付页查看可用币种后再比较。";
        }
        CurrencyQuote best = rankByCnyCost(quotes).get(0);
        return "按你实际结算页提供的报价，当前最低最终成本为 " + best.currency
                + "（" + best.paymentMethod + "），折合人民币 "
                + String.format(java.util.Locale.US, "%.2f", best.cnyTotal) + "。";
    }
}
