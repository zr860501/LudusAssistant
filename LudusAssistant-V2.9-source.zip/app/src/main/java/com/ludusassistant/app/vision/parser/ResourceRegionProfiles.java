package com.ludusassistant.app.vision.parser;

import java.util.Arrays;
import java.util.List;

/** Versioned normalized screen profiles for icon-only resource counters. */
public final class ResourceRegionProfiles {
    private ResourceRegionProfiles() {}

    /** Matches the top resource bar observed in the supplied LUDUS portrait capture. */
    public static List<SpatialResourceParser.Region> ludusTopBarV1() {
        return Arrays.asList(
                new SpatialResourceParser.Region("gold", 0.40f, 0.025f, 0.66f, 0.17f, 0.70f),
                new SpatialResourceParser.Region("emeralds", 0.66f, 0.025f, 0.95f, 0.17f, 0.70f)
        );
    }
}
