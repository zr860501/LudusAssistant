package com.ludusassistant.app;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.widget.Button;
import com.ludusassistant.app.capture.CaptureService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import com.ludusassistant.app.data.*;
import com.ludusassistant.app.sync.NetworkState;
import com.ludusassistant.app.hero.HeroRepository;
import com.ludusassistant.app.hero.HeroAdvisor;
import com.ludusassistant.app.account.PlayerIdStore;
import com.ludusassistant.app.account.OfficialWebShop;
import com.ludusassistant.app.shop.ShopCatalog;
import com.ludusassistant.app.shop.ShopItem;
import com.ludusassistant.app.shop.ShopAdvisor;
import android.content.ClipData;
import android.content.ClipboardManager;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private AppStore store; private GuideRepository guides; private EventStore events; private HeroRepository heroes;
    private TextView status, resources, calendar, guide, pvp, ledger, playerState, shopSummaryView, dailyPlan;
    private EditText playerIdInput;
    private PlayerIdStore playerIds; private com.ludusassistant.app.account.AccountSnapshotStore snapshots;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private static final int REQ_CAPTURE=4108;
    private final Runnable hourly=()->{ render(); handler.postDelayed(hourly,60L*60L*1000L); };
    @Override public void onCreate(Bundle b){super.onCreate(b); store=new AppStore(this); guides=new GuideRepository(this); events=new EventStore(this); heroes=new HeroRepository(this); playerIds=new PlayerIdStore(this); snapshots=new com.ludusassistant.app.account.AccountSnapshotStore(this); setContentView(build()); render(); RefreshScheduler.schedule(this); handler.postDelayed(hourly,60L*60L*1000L);}
    private LinearLayout build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24); root.setBackgroundColor(Color.rgb(246,247,250));
        TextView title=t("LUDUS ASSISTANT",28,true); root.addView(title);
        status=t("正在检查网络…",14,false); root.addView(status);
        Button startCapture=new Button(this); startCapture.setText("开始屏幕观测"); startCapture.setOnClickListener(v->requestCapture()); root.addView(startCapture, lp(-1, -2));
        Button stopCapture=new Button(this); stopCapture.setText("停止屏幕观测"); stopCapture.setOnClickListener(v->stopCapture()); root.addView(stopCapture, lp(-1, -2));
        root.addView(section("Player ID / 账号数据"));
        LinearLayout idRow=new LinearLayout(this); idRow.setOrientation(LinearLayout.HORIZONTAL);
        playerIdInput=new EditText(this); playerIdInput.setSingleLine(true); playerIdInput.setHint("输入 LUDUS Player ID"); playerIdInput.setText(playerIds.get());
        idRow.addView(playerIdInput,new LinearLayout.LayoutParams(0,-2,1f));
        Button paste=new Button(this); paste.setText("粘贴"); paste.setOnClickListener(v->pastePlayerId()); idRow.addView(paste,new LinearLayout.LayoutParams(-2,-2));
        root.addView(idRow);
        Button saveId=new Button(this); saveId.setText("保存 Player ID"); saveId.setOnClickListener(v->savePlayerId()); root.addView(saveId,lp(-1,-2));
        Button openShop=new Button(this); openShop.setText("用 Player ID 打开官方 Web Shop"); openShop.setOnClickListener(v->openOfficialShop()); root.addView(openShop,lp(-1,-2));
        playerState=t("正在检查 Player ID 数据能力…",14,false); root.addView(card(playerState));

        root.addView(section("官方商店 / 性价比"));
        TextView shopSummary=t("正在读取官方商店公开商品快照…",15,false);
        root.addView(card(shopSummary));
        Button openShopCenter=new Button(this); openShopCenter.setText("打开官方商店");
        openShopCenter.setOnClickListener(v->openOfficialShop()); root.addView(openShopCenter,lp(-1,-2));
        TextView currencyNote=t("支付币种只按官方结算页实际显示的报价比较；不会虚构汇率，也不会替你修改购买国家。最终付款必须由你在官方支付页确认。",13,false);
        root.addView(currencyNote,lp(0,18));
        this.shopSummaryView=shopSummary;
        root.addView(section("实时资源")); resources=t("暂无观测数据",17,false); root.addView(card(resources));
        root.addView(section("今日游戏日历")); calendar=t("暂无活动数据",16,false); root.addView(card(calendar));
        root.addView(section("今日账号计划")); dailyPlan=t("正在生成今日计划…",16,false); root.addView(card(dailyPlan));
        root.addView(section("攻略中心 · 英雄图鉴")); guide=t("暂无攻略",16,false); root.addView(card(guide));
        root.addView(section("资源变化")); ledger=t("暂无变化记录",15,false); root.addView(card(ledger));
        root.addView(section("PVP 分析")); pvp=t("当前积分：—\n对局记录：—\n仅提供分析建议，不执行游戏操作。",16,false); root.addView(card(pvp));
        TextView note=t("数据原则：游戏状态以本机观测为主；攻略目标刷新周期 60 分钟；网络中断时继续使用本地缓存。",13,false); root.addView(note,lp(0,18));
        ScrollView sc=new ScrollView(this); sc.addView(root); return sc;
    }
    private TextView t(String s,int z,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(Color.rgb(24,26,32));if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private TextView card(TextView v){v.setPadding(16,16,16,16);v.setBackgroundColor(Color.WHITE);return v;}
    private TextView section(String s){TextView v=t(s,20,true);v.setPadding(0,20,0,8);return v;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private void render(){
        boolean online=NetworkState.connected(this);
        android.content.SharedPreferences cp=getSharedPreferences("ludus_capture",MODE_PRIVATE);
        String page=cp.getString("last_page","UNKNOWN");
        float conf=cp.getFloat("last_ocr_confidence",0f);
        status.setText((online?"● 网络可用":"○ 离线模式")+" · 观测页 "+page+" · OCR "+String.format(Locale.getDefault(),"%.0f%%",conf*100f)+" · 攻略周期 60 分钟");
        JSONObject r=store.resources(); resources.setText("💎 钻石  "+val(r,"diamonds")+"\n🟢 祖母绿  "+val(r,"emeralds")+"\n🪙 金币  "+val(r,"gold")+"\n🎟 代币  "+val(r,"tokens"));
        JSONArray ev=events.all(); StringBuilder eb=new StringBuilder(); if(ev.length()==0) eb.append("尚无实时活动事件。连接同步后自动填充。\n"); for(int i=0;i<ev.length();i++){JSONObject o=ev.optJSONObject(i); if(o!=null) eb.append("• ").append(o.optString("title","未命名")).append(" · ").append(o.optString("priority","—")).append("\n");} calendar.setText(eb.toString());
        JSONArray ga=guides.current(); StringBuilder gb=new StringBuilder(); gb.append("攻略数据版本：").append(guides.version()).append("\n"); for(int i=0;i<ga.length();i++){JSONObject o=ga.optJSONObject(i); if(o!=null) gb.append("• ").append(o.optString("title")).append(" · ").append(o.optString("priority")).append("\n");} guide.setText(gb.toString()+"\n【英雄知识库】\n"+heroes.grouped()+"\n\n【英雄培养建议】\n"+HeroAdvisor.summary(heroes.list(), "", null, 5)+"\n\n示例详情：\n"+heroes.detail("storm"));
        JSONArray log=store.resourceLog(); StringBuilder lb=new StringBuilder(); int start=Math.max(0,log.length()-8); for(int i=log.length()-1;i>=start;i--){JSONObject o=log.optJSONObject(i); if(o!=null) lb.append(fmt(o.optLong("ts"))).append("  ").append(o.optString("resource")).append("  ").append(o.optString("delta","—")).append("  [").append(o.optString("source","unknown")).append("]\n");} ledger.setText(lb.length()==0?"暂无变化记录":lb.toString());
        pvp.setText("当前积分：待游戏界面观测\n对局记录：待首次采集\n策略分析：准备就绪\n\n说明：本模块只分析你提供的对局状态，不自动点击、投降或操纵游戏。");
        if (dailyPlan != null) dailyPlan.setText(DailyPlanner.build(r, ev).summary());
        if (shopSummaryView != null) {
            ShopItem emerald = ShopCatalog.bestForEmeralds();
            ShopItem gold = ShopCatalog.bestForGold();
            ShopItem points = ShopCatalog.bestForStorePoints();
            StringBuilder sb = new StringBuilder();
            sb.append("官方商店公开快照（USD）\n");
            if (emerald != null) sb.append("🟢 纯祖母绿单位价值最高：").append(emerald.name).append(" · ")
                    .append(emerald.emeralds).append(" / $").append(String.format(Locale.US,"%.2f", emerald.priceUsd))
                    .append(" = ").append(String.format(Locale.US,"%.1f", emerald.emeraldsPerUsd())).append(" Emerald/USD\n");
            if (gold != null) sb.append("🪙 纯金币单位价值最高：").append(gold.name).append(" · ")
                    .append(gold.gold).append(" / $").append(String.format(Locale.US,"%.2f", gold.priceUsd))
                    .append(" = ").append(String.format(Locale.US,"%.0f", gold.goldPerUsd())).append(" Gold/USD\n");
            if (points != null) sb.append("⭐ Store Points 单位价值最高：").append(points.name).append(" · ")
                    .append(String.format(Locale.US,"%.2f", points.pointsPerUsd())).append(" Points/USD\n");
            sb.append("\n注意：礼包中的英雄、Astral Echo 等非同质资源没有被粗暴换算成现金，因此会单独标记为“组合礼包”，避免虚假的综合评分。\n");
            sb.append("\n免费商品优先：每周 100 Emerald、每日 500 Gold、每日 Clan Medals、每日 Atlantis Tokens（以官方页面实际状态为准）。\n");
            ShopAdvisor.Recommendation rec = ShopAdvisor.recommend(r, ShopCatalog.currentPublicSnapshot());
            sb.append("\n【账号感知购买建议】\n").append(rec.summary()).append("\n");
            sb.append("\n当前公开商店数据不是实时支付报价；付款币种/税费/支付方式以官方结算页为准。");
            shopSummaryView.setText(sb.toString());
        }
        String pid=playerIds.get();
        com.ludusassistant.app.account.AccountSnapshot snap = snapshots.get();
        if (!pid.isEmpty() && snap.observedAt == 0) {
            snapshots.save(com.ludusassistant.app.data.AccountSnapshotBuilder.fromObserved(pid, store, snap), "local-observation", conf);
            snap = snapshots.get();
        }
        playerState.setText(pid.isEmpty()?"尚未保存 Player ID\n\n能力状态：\n• 官方 Web Shop：支持按 user-id 进入\n• 完整游戏资料 API：目前未发现官方公开接口\n• 本地 OCR：作为备用数据源\n\n不会猜测或伪造服务器接口。":"Player ID："+pid+"\n最近账号快照："+(snap.observedAt == 0 ? "暂无" : fmt(snap.observedAt))+"\n快照来源："+snap.source()+"\n\n能力状态：\n• 官方 Web Shop 身份入口：已确认\n• 完整游戏资料 API：尚未确认\n• 本机 OCR：备用数据源");
    }
    private void pastePlayerId(){
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        if(cm!=null && cm.hasPrimaryClip()){
            ClipData d=cm.getPrimaryClip();
            if(d!=null && d.getItemCount()>0){
                CharSequence x=d.getItemAt(0).coerceToText(this);
                if(x!=null) playerIdInput.setText(x.toString().trim());
            }
        }
    }

    private boolean savePlayerId(){
        String id=playerIdInput.getText()==null?"":playerIdInput.getText().toString().trim();
        if(!PlayerIdStore.isValid(id)){
            playerState.setText("Player ID 格式无效。仅保存明确输入的 ID，不猜测。" );
            return false;
        }
        playerIds.set(id);
        playerState.setText("已保存 Player ID："+id+"\nWeb Shop 身份入口：已确认\n完整游戏资料 API：尚未确认" );
        return true;
    }

    private void openOfficialShop(){
        String id=playerIdInput.getText()==null?"":playerIdInput.getText().toString().trim();
        if(!PlayerIdStore.isValid(id)){
            playerState.setText("请先输入有效 Player ID。" );
            return;
        }
        playerIds.set(id);
        try { OfficialWebShop.open(this,id); } catch(Exception e){ playerState.setText("无法打开官方 Web Shop："+e.getMessage()); }
    }

    private void requestCapture(){
        MediaProjectionManager mpm=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(),REQ_CAPTURE);
    }

    private void stopCapture(){
        Intent i=new Intent(this,CaptureService.class); i.setAction(CaptureService.ACTION_STOP); startService(i);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQ_CAPTURE || resultCode!=RESULT_OK || data==null) return;
        Intent i=new Intent(this,CaptureService.class); i.setAction(CaptureService.ACTION_START);
        i.putExtra(CaptureService.EXTRA_RESULT_CODE,resultCode); i.putExtra(CaptureService.EXTRA_DATA,data);
        if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        status.setText("● 屏幕观测已启动 · 仅采集/分析，不自动操作游戏");
    }

    private String val(JSONObject o,String k){return o.has(k)?o.optString(k,"—"):"—";}
    private String fmt(long x){return new SimpleDateFormat("MM-dd HH:mm",Locale.getDefault()).format(new Date(x));}
    @Override protected void onDestroy(){handler.removeCallbacks(hourly);super.onDestroy();}
}
