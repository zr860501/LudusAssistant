package com.ludusassistant.app.shop;

import org.json.JSONObject;
import java.util.List;
import java.util.Locale;

/**
 * Account-aware purchase advisor. It ranks only homogeneous resources that are
 * explicitly present in the local account snapshot. It never invents a cash
 * value for heroes, Astral Echo, runes, etc.
 */
public final class ShopAdvisor {
    private ShopAdvisor() {}

    public static Recommendation recommend(JSONObject resources, List<ShopItem> catalog) {
        long emeralds = resources == null ? -1 : resources.optLong("emeralds", -1);
        long gold = resources == null ? -1 : resources.optLong("gold", -1);
        long tokens = resources == null ? -1 : resources.optLong("tokens", -1);

        if (emeralds >= 0 && emeralds < 1000) {
            ShopItem item = best(catalog, "Emeralds");
            if (item != null) return new Recommendation(item, "祖母绿库存偏低（" + emeralds + "），优先考虑纯祖母绿档位。", 90);
        }
        if (gold >= 0 && gold < 100000) {
            ShopItem item = best(catalog, "Gold");
            if (item != null) return new Recommendation(item, "金币库存偏低（" + gold + "），优先考虑纯金币档位。", 75);
        }
        if (tokens >= 0 && tokens < 100) {
            return new Recommendation(null, "代币偏低（" + tokens + "）。当前不把代币需求强行映射为现金购买，等待活动/商店具体商品。", 65);
        }
        return new Recommendation(null, "当前没有足够的账号资源目标用于生成个性化付费建议；先领取免费商品，再查看官方结算页报价。", 50);
    }

    private static ShopItem best(List<ShopItem> catalog, String category) {
        ShopItem result = null;
        if (catalog == null) return null;
        for (ShopItem item : catalog) {
            if (!category.equals(item.category) || item.priceUsd <= 0) continue;
            if (result == null) result = item;
            else if ("Emeralds".equals(category) && item.emeraldsPerUsd() > result.emeraldsPerUsd()) result = item;
            else if ("Gold".equals(category) && item.goldPerUsd() > result.goldPerUsd()) result = item;
        }
        return result;
    }

    public static final class Recommendation {
        public final ShopItem item;
        public final String reason;
        public final int score;
        public Recommendation(ShopItem item, String reason, int score) {
            this.item = item; this.reason = reason; this.score = score;
        }
        public String summary() {
            if (item == null) return reason + "\n推荐度：" + score + "/100";
            return String.format(Locale.US, "%s\n%s\n推荐度：%d/100", item.name, reason, score);
        }
    }
}
