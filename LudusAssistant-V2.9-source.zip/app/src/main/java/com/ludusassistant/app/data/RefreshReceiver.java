package com.ludusassistant.app.data;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class RefreshReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i){
        // Network ingestion is intentionally isolated from UI. This receiver marks a refresh window;
        // a future sync service can fetch/validate remote data without blocking the main thread.
        GuideRepository g=new GuideRepository(c);
        if(g.due()){
            AppStore s=new AppStore(c); s.markSync();
        }
    }
}
