package com.ludusassistant.app.account;

import org.json.JSONArray;
import org.json.JSONObject;

/** Local normalized account snapshot. Values are optional until an official/authorized source supplies them. */
public final class AccountSnapshot {
    public final String playerId;
    public final long observedAt;
    public final JSONObject resources;
    public final JSONArray heroes;
    public final JSONArray spells;
    public final JSONObject pvp;
    public final JSONArray events;

    public AccountSnapshot(String playerId, long observedAt, JSONObject resources,
                           JSONArray heroes, JSONArray spells, JSONObject pvp, JSONArray events) {
        this.playerId = playerId == null ? "" : playerId;
        this.observedAt = observedAt;
        this.resources = resources == null ? new JSONObject() : resources;
        this.heroes = heroes == null ? new JSONArray() : heroes;
        this.spells = spells == null ? new JSONArray() : spells;
        this.pvp = pvp == null ? new JSONObject() : pvp;
        this.events = events == null ? new JSONArray() : events;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("playerId", playerId);
            o.put("observedAt", observedAt);
            o.put("resources", resources);
            o.put("heroes", heroes);
            o.put("spells", spells);
            o.put("pvp", pvp);
            o.put("events", events);
        } catch (Exception ignored) { }
        return o;
    }
}
