package com.ludusassistant.app.data;

import com.ludusassistant.app.shop.ShopCatalog;
import com.ludusassistant.app.shop.ShopItem;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Conservative daily planner: free rewards first, then event tasks, then loyalty/reward
 * actions, and paid purchases only when an explicit resource threshold is crossed.
 * It never fabricates a value for heterogeneous items.
 */
public final class DailyPlanner {
    private DailyPlanner() {}

    public static Plan build(JSONObject resources, JSONArray events) {
        List<Action> actions = new ArrayList<>();
        long emeralds = resources == null ? -1 : resources.optLong("emeralds", -1);
        long gold = resources == null ? -1 : resources.optLong("gold", -1);
        long storePoints = resources == null ? -1 : resources.optLong("store_points", -1);

        actions.add(new Action(100, "免费奖励", "优先领取官方商店当前可领取的免费奖励（以实时商店页面为准）。"));

        if (events != null) {
            for (int i = 0; i < events.length(); i++) {
                JSONObject e = events.optJSONObject(i);
                if (e == null) continue;
                String title = e.optString("title", "未命名活动");
                String priority = e.optString("priority", "普通");
                int score = "高".equals(priority) ? 95 : ("中".equals(priority) ? 75 : 55);
                actions.add(new Action(score, "活动", "优先检查：" + title));
            }
        }

        if (storePoints >= 0) {
            actions.add(new Action(85, "Loyalty Shop", "当前 Store Points：" + storePoints + "。先检查限购兑换，再考虑付费获取积分。"));
        } else {
            actions.add(new Action(70, "Loyalty Shop", "尚未获得 Store Points；等待账号数据同步后再做个性化兑换排序。"));
        }

        if (emeralds >= 0 && emeralds < 1000) {
            ShopItem best = ShopCatalog.bestForEmeralds();
            if (best != null) actions.add(new Action(40, "付费资源", "祖母绿低于 1000；如确有购买需求，可比较 " + best.name + "，但先确认官方结算页最终价格。"));
        } else if (emeralds >= 0) {
            actions.add(new Action(20, "资源管理", "祖母绿当前为 " + emeralds + "；没有因为库存正常而强行推荐购买。"));
        }

        if (gold >= 0 && gold < 100000) {
            ShopItem best = ShopCatalog.bestForGold();
            if (best != null) actions.add(new Action(35, "付费资源", "金币低于 100000；如确有购买需求，可比较 " + best.name + "，但先确认官方结算页最终价格。"));
        }

        actions.sort(Comparator.comparingInt((Action a) -> a.priority).reversed());
        return new Plan(actions);
    }

    public static final class Action {
        public final int priority;
        public final String type;
        public final String text;
        public Action(int priority, String type, String text) { this.priority = priority; this.type = type; this.text = text; }
    }

    public static final class Plan {
        public final List<Action> actions;
        public Plan(List<Action> actions) { this.actions = actions; }
        public String summary() {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < actions.size(); i++) {
                Action a = actions.get(i);
                b.append(i + 1).append(". [").append(a.type).append("] ").append(a.text).append("\n");
            }
            return b.toString().trim();
        }
    }
}
