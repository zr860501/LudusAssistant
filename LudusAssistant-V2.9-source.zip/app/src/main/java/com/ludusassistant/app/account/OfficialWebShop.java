package com.ludusassistant.app.account;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/** Opens the official LUDUS Web Shop using Xsolla's documented user-id authentication parameter. */
public final class OfficialWebShop {
    private static final String BASE = "https://site.ludus-game.com/";
    private OfficialWebShop() {}

    public static void open(Context context, String playerId) {
        if (!PlayerIdStore.isValid(playerId)) throw new IllegalArgumentException("Invalid Player ID");
        Uri uri = Uri.parse(BASE).buildUpon().appendQueryParameter("user-id", playerId.trim()).build();
        context.startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }
}
