package com.ludusassistant.app.sync;

/** Policy only: decides when a cloud refresh is desirable. No network client is embedded here. */
public final class SyncPolicy {
    public static final long GUIDE_INTERVAL_MS=60L*60L*1000L;
    public static boolean due(long lastUpdate){ return System.currentTimeMillis()-lastUpdate>=GUIDE_INTERVAL_MS; }
}
