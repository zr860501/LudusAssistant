package com.ludusassistant.app.data;

import android.content.Context;
import org.json.JSONObject;

/**
 * Converts a single observed resource snapshot into ledger entries.
 * The engine never changes the game; it only records observations supplied by a UI/OCR layer.
 */
public final class ObservationEngine {
    private final AppStore store;
    public ObservationEngine(Context c){ store=new AppStore(c); }
    public void accept(JSONObject snapshot, String source){
        if(snapshot==null) return;
        String[] keys={"diamonds","emeralds","gold","tokens"};
        for(String k:keys){
            if(snapshot.has(k) && !snapshot.isNull(k)){
                long v=snapshot.optLong(k,Long.MIN_VALUE);
                if(v!=Long.MIN_VALUE) store.observe(k,v,source);
            }
        }
    }
}
