package com.ludusassistant.app.vision.resource;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Canonical resource keys observed in the supplied expanded LUDUS resource panel. */
public final class LudusResourceCatalog {
    public static final class Definition {
        public final String key;
        public final List<String> labels;
        public Definition(String key, String... labels) {
            this.key = key;
            this.labels = Collections.unmodifiableList(Arrays.asList(labels));
        }
    }

    private static final List<Definition> DEFINITIONS = Collections.unmodifiableList(Arrays.asList(
            new Definition("gold", "金币"),
            new Definition("emeralds", "祖母绿"),
            new Definition("super_crystals", "超凡水晶"),
            new Definition("enhanced_super_crystals", "增强超凡水晶"),
            new Definition("water_essence", "水系精华"),
            new Definition("earth_essence", "土系精华"),
            new Definition("wind_essence", "风系精华"),
            new Definition("fire_essence", "火系精华"),
            new Definition("gloves", "手套"),
            new Definition("teeth", "牙齿"),
            new Definition("gold_teeth", "金牙"),
            new Definition("tribe_coins", "部族币"),
            new Definition("runes", "符文"),
            new Definition("golden_runes", "黄金符文"),
            new Definition("fortune_dice", "命运之骰"),
            new Definition("wild_cards", "百搭牌")
    ));

    private static final Map<String, String> LABEL_TO_KEY;
    static {
        Map<String, String> m = new HashMap<>();
        for (Definition d : DEFINITIONS) for (String label : d.labels) m.put(label, d.key);
        LABEL_TO_KEY = Collections.unmodifiableMap(m);
    }

    private LudusResourceCatalog() {}
    public static List<Definition> definitions() { return DEFINITIONS; }
    public static String keyForLabel(String label) { return LABEL_TO_KEY.get(label); }
}
