package com.ludusassistant.app.data;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Iterator;

/** Local-first store. Resource observations are append-only and can later be synced. */
public final class AppStore {
    private final SharedPreferences p;
    private static final String RES="resources";
    private static final String LOG="resource_log";
    private static final String SYNC="last_sync";
    public AppStore(Context c){ p=c.getSharedPreferences("ludus_store",Context.MODE_PRIVATE); }
    public synchronized JSONObject resources(){
        try{return new JSONObject(p.getString(RES,"{}"));}catch(Exception e){return new JSONObject();}
    }
    public synchronized void observe(String key,long value,String source){
        try{
            JSONObject before=resources(); long old=before.optLong(key,Long.MIN_VALUE);
            before.put(key,value); p.edit().putString(RES,before.toString()).apply();
            JSONObject row=new JSONObject().put("ts",System.currentTimeMillis()).put("resource",key).put("before",old==Long.MIN_VALUE?JSONObject.NULL:old).put("after",value).put("delta",old==Long.MIN_VALUE?JSONObject.NULL:value-old).put("source",source==null?"unknown":source);
            JSONArray log=resourceLog(); log.put(row); while(log.length()>1000) log.remove(0); p.edit().putString(LOG,log.toString()).apply();
        }catch(Exception ignored){}
    }
    public synchronized JSONArray resourceLog(){try{return new JSONArray(p.getString(LOG,"[]"));}catch(Exception e){return new JSONArray();}}
    public synchronized long lastSync(){return p.getLong(SYNC,0);}
    public synchronized void markSync(){p.edit().putLong(SYNC,System.currentTimeMillis()).apply();}
    public synchronized void clear(){p.edit().clear().apply();}
}
