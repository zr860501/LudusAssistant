package com.ludusassistant.app.automation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Converts confirmed user preferences and current observations into an ordered task plan.
 * It deliberately separates planning from execution: no task is clicked or launched here.
 */
public final class AutomationPlanner {
    private AutomationPlanner() {}

    public static List<AutomationTask> buildDailyPlan(boolean loggedInToday,
                                                       boolean freeRewardAvailable,
                                                       boolean tokenTaskAvailable,
                                                       boolean pvpAvailable,
                                                       boolean eventTaskAvailable,
                                                       boolean resourceScanRequested,
                                                       boolean shopCheckRequested,
                                                       long now) {
        List<AutomationTask> out = new ArrayList<>();
        if (!loggedInToday) out.add(new AutomationTask("daily-login", TaskType.DAILY_LOGIN,
                "每日登录", 100, false, now, 0));
        if (freeRewardAvailable) out.add(new AutomationTask("free-reward", TaskType.FREE_REWARD,
                "领取免费奖励", 98, true, now, 0));
        if (eventTaskAvailable) out.add(new AutomationTask("event-task", TaskType.EVENT_TASK,
                "完成当前活动任务", 95, true, now, 0));
        if (tokenTaskAvailable) out.add(new AutomationTask("token-task", TaskType.TOKEN_TASK,
                "完成代币任务", 90, true, now, 0));
        if (pvpAvailable) out.add(new AutomationTask("pvp", TaskType.PVP_MATCH,
                "执行 PVP 对局", 85, true, now, 0));
        if (resourceScanRequested) out.add(new AutomationTask("resource-scan", TaskType.RESOURCE_SCAN,
                "扫描账号资源", 80, false, now, 0));
        if (shopCheckRequested) out.add(new AutomationTask("shop-check", TaskType.SHOP_CHECK,
                "检查官方商店", 70, false, now, 0));
        out.sort(Comparator.comparingInt((AutomationTask t) -> t.priority).reversed());
        return Collections.unmodifiableList(out);
    }

    /** Apply the user's explicit approval to selected task IDs only. */
    public static void approve(List<AutomationTask> tasks, List<String> approvedIds) {
        if (tasks == null || approvedIds == null) return;
        for (AutomationTask t : tasks) {
            if (t.requiresApproval && approvedIds.contains(t.id) && t.state == TaskState.AVAILABLE) {
                t.state = TaskState.APPROVED;
            }
        }
    }

    /**
     * Decide what should happen at the current moment. During a PVP match,
     * ad-reward work is deferred until the match finishes.
     */
    public static AutomationTask nextRunnable(List<AutomationTask> tasks, long now,
                                              long lastAdAt, boolean inMatch) {
        if (tasks == null) return null;
        for (AutomationTask t : tasks) {
            if (t.eligible(now, lastAdAt, inMatch)) return t;
        }
        return null;
    }

    public static TaskState stateAfterMatch(boolean adDue) {
        return adDue ? TaskState.WAITING_FOR_AD : TaskState.AVAILABLE;
    }
}
