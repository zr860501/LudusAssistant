# Ludus Assistant V2.0

Android 原生 Java 工程，当前目标：离线优先的 LUDUS 数据/攻略助手 + 用户主动授权的屏幕观测。

## V1.9 本轮新增
- 接入本地 ML Kit OCR（Latin + Chinese bundled model）。
- OCR 采用单任务串行策略：上一帧仍在识别时丢弃新帧，避免队列堆积。
- OCR 结果进入 ObservationPipeline；只有识别到明确标注的资源值且与上一可信值不同才写入资源账本。
- App 状态栏显示最近识别页面与 OCR 置信度。


## V2.0 本轮新增：Player ID / 官方 Web Shop 路线
- 新增 Player ID 本地输入与校验。
- 新增“复制的 Player ID”一键读取入口（仅用户点击时读取剪贴板）。
- 新增“用 Player ID 打开官方 LUDUS Web Shop”入口，使用官方 Xsolla Web Shop 的 `user-id` 查询参数模式。
- 新增 Player ID 数据能力状态页：明确区分“Web Shop 身份入口已确认”和“完整游戏资料 API 尚未确认”，不猜测服务器接口。
- 新增 AccountSnapshot 本地数据模型，用于未来接入官方/授权数据源后统一保存玩家资料、资源、英雄、法术、PVP 与活动摘要。

### 当前关于 Player ID 的结论
TOP APP GAMES 的官方站点链接到 LUDUS 官方 Web Shop；该 Web Shop 明确提供“Your user ID”登录入口。Xsolla 官方文档明确说明，启用 User ID 授权的 Web Shop 可以使用 `?user-id=<USER_ID>` 自动认证。
这证明 Player ID 可以作为 Web Shop 的用户身份入口；但目前没有找到 TOP APP GAMES 对外公布的“仅凭 Player ID 返回完整游戏账号数据”的官方 API，因此 V2.0 不会伪造或猜测 API endpoint。

官方资料：
- https://site.ludus-game.com/
- https://developers.xsolla.com/solutions/web-shop/promotions/query-parameters/
- https://www.topapp.games/


## V2.1 本轮新增：官方商店购买助手
- 新增官方商店商品快照模型，当前公开 USD 价格作为本地缓存，不伪装成实时支付报价。
- 新增 Emerald / Gold / Store Points 的单位价值计算。
- 组合礼包与单资源商品分开处理，避免把英雄、Astral Echo 等异质资源粗暴折现后产生虚假“综合性价比”。
- 新增支付币种比较模型：只接受官方结算页实际显示的报价，按最终人民币成本排序。
- 明确不自动修改购买国家、不伪造汇率、不保存银行卡/支付凭证。
- 付款前保留明确的用户确认边界；App 只负责分析与进入官方 Web Shop，实际支付由 LUDUS/Xsolla 官方页面完成。

### 当前公开商店快照
官方商店当前公开页面显示：Emerald 650/$5.40、1500/$10.80、3200/$21.60、8300/$54.00、17500/$108.00；Gold 5000/$2.88、25000/$10.71、60000/$20.07、140000/$38.70、350000/$73.40。官方页面还列出 Special Offers、Battle Passes、Licenses、Might Passes、Ludus Royal、Spells、Runes、Dice of Fortune、Gold、Emeralds、Rewards Market、Rewards Chain 和 Loyalty Shop。价格会变化，因此这些数值只是公开页面快照。

## 数据路线优先级
1. 官方/授权 Player ID 数据源（如果后续确认存在）
2. 官方 Web Shop 可见数据
3. 本机 MediaProjection + OCR 观测
4. 本地历史快照

## 安全边界
V2.0 只读取用户主动提供的 Player ID，并打开官方 Web Shop；不尝试伪造认证、不修改服务器数据、不绕过游戏反作弊。

## V1.8 本轮新增
- MediaProjection 屏幕观测前台服务骨架。
- Android 14+ 所需 `mediaProjection` 前台服务类型与权限。
- App 内“开始屏幕观测/停止屏幕观测”入口。
- 屏幕帧节流（约 4 FPS 上限）并记录最后一帧尺寸/时间，用于后续 OCR/Observation 接入。
- 明确：本服务只采集和分析，不自动点击、投降、施法、观看广告，也不绕过反作弊。

## 当前能力
- 本地资源账本：钻石、祖母绿、金币、代币。
- 活动/攻略本地缓存与 60 分钟刷新策略骨架。
- 英雄知识库与版本字段。
- PVP 观察/分析数据模型。
- 网络状态检测与离线优先设计。
- MediaProjection 授权与前台采集链路。
- 本地 OCR 识别链路。

## 构建环境
- Android Gradle Plugin: 8.7.3
- compileSdk: 35
- targetSdk: 35
- minSdk: 26
- Java: 21

当前工作区没有 Android SDK/Gradle，因此本环境只能完成源码与静态检查，不能诚实地声称已经产出并验证 APK。

## 真机测试
1. 用 Android Studio 打开本工程。
2. 安装 Android SDK 35、Build Tools 35.x。
3. Sync Gradle。
4. 在 Mate 60 Pro 上安装 debug APK。
5. 打开 App，点击“开始屏幕观测”。
6. 接受系统屏幕录制授权。
7. 返回 App 后确认前台服务通知出现。
8. 后续再接入 OCR 与 LUDUS 页面识别。

## Android MediaProjection 约束
Android 14+ 要求 MediaProjection 使用对应的前台服务类型，并声明 `FOREGROUND_SERVICE_MEDIA_PROJECTION`；每次新的捕获会话都需要用户重新授权。
