# LUDUS Assistant V2.5

本版本把用户提供的 Mate 60 Pro 广告录像纳入观测解析基线。

## 本阶段实际验证
- 录像 `SVID_20260824_154924_1.mp4`：51.536 秒，592×1280，H.264。
- 录像中可观察到 LUDUS 商店页面 → 外部广告（Clash of Clans）→ 外部应用安装卡片的过渡。
- 关键广告画面包含 `Play Now!`；安装卡片包含 `Clash of Clans` / `安装`。
- 这些画面已加入屏幕分类器的规则，但不会据此声称“自动点击”已经完成。

## 本阶段代码变化
- `GamePage` 增加 `ADVERTISEMENT` 与 `EXTERNAL_APP_INSTALL`。
- `ScreenTextParser` 增加简体中文游戏页面关键词以及广告/外部安装识别。
- `ResourceTextParser` 增加中文资源标签：钻石、祖母绿、金币、代币、奖杯。

## 验证
- Java parser smoke test: PASS
- 真实录像关键帧人工检查: PASS
- OCR 关键帧可识别部分文本；顶部资源图标没有文字标签，因此当前版本不会伪造资源值。

## 重要边界
当前工程是 Android 工程（可作为 HarmonyOS 4.2 设备上的 Android 应用路线进行真机验证），不是已经由 DevEco Studio 编译验证的原生 HarmonyOS 工程。尚未生成可声称为最终版的 HAP。
