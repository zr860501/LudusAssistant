# Build / Test Checklist

## Required
- Android Studio
- Android SDK Platform 35
- Android SDK Build-Tools 35.x
- JDK 21
- Gradle/Android Gradle Plugin 8.7.3 compatible environment

## Project
`settings.gradle` -> root project `LudusAssistant`
`app/build.gradle` -> application id `com.ludusassistant.app`

## First smoke test
- Build debug APK.
- Install on Huawei Mate 60 Pro.
- Grant screen-capture permission.
- Verify foreground notification.
- Verify capture stats update in `ludus_capture` preferences.

## Known limitation
The current capture service intentionally stops at frame acquisition/metadata recording. OCR and game-page parsing are not yet wired to a real OCR engine. This is deliberate: the next stage must validate the actual OCR engine against the three supplied Mate 60 Pro recordings before claiming recognition accuracy.


## V1.9 OCR 依赖
使用 Google ML Kit bundled text recognition：Latin + Chinese。Bundled 模型随 APK 提供，首次安装后不依赖运行时动态下载，适合离线优先设计。
