# LUDUS Assistant V2.6

## 本阶段目标
解决 LUDUS 顶部资源只有图标、没有文字标签时，普通 OCR 无法判断数字归属的问题。

## 实现
- `OcrToken` 保存 OCR 文本、置信度和像素边界框。
- `OcrEngine.Result` 保留 token 空间信息。
- `SpatialResourceParser` 使用显式的归一化屏幕区域关联数字。
- `ResourceRegionProfiles` 提供版本化的 LUDUS 顶部资源栏 V1 配置。
- `ObservationPipeline.process(OcrEngine.Result)` 同时处理文字标签和空间资源。
- `CaptureService` 将空间关联结果记录为 `ocr+spatial`。

## 保守规则
- 只有数字 token 才可能进入空间解析。
- token 必须位于显式配置的资源区域内。
- token 置信度低于阈值会被忽略。
- 区域外数字不会被猜测为资源。
- 当前配置仅覆盖金币和祖母绿；其它资源必须有真实画面证据后再增加区域。

## 验证
- Java 空间解析回归测试：PASS
- 712×1280 坐标模拟：金币 338527、祖母绿 16460 正确关联
- 区域外数字：正确忽略
- Java 源码大括号结构检查：PASS
- 尚未进行 Android Gradle / 真机编译验证。
