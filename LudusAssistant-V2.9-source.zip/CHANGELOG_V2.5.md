# Changelog V2.5

- Added advertisement/external-install screen states.
- Added Simplified Chinese screen classification keywords.
- Added Chinese resource-label parsing.
- Added evidence note based on supplied Mate 60 Pro recording.
- Added explicit distinction between observed OCR text and inferred/icon-only values.
- Corrected documentation: current source baseline is Android, not a verified native HarmonyOS/DevEco build.

## V2.6 development changes
- OCR results now retain token bounding boxes and confidence values.
- Added versioned normalized top-bar resource regions for icon-only Gold/Emerald counters.
- ObservationPipeline can associate numeric OCR tokens with explicit resource regions.
- CaptureService persists spatially-associated observations as `ocr+spatial`.
- The parser remains conservative: unlabeled numbers outside configured regions are ignored.
